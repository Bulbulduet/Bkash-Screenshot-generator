const express = require("express");
const puppeteer = require("puppeteer");
const path = require("path");
const ejs = require("ejs");
const bodyParser = require("body-parser");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: true }));

app.post("/generate", async (req, res) => {
  const { number, amount, reference, trxid, date } = req.body;

  const html = await ejs.renderFile(
    path.join(__dirname, "templates", "screenshot.ejs"),
    { number, amount, reference, trxid, date }
  );

  const browser = await puppeteer.launch({
    headless: "new",
    args: ["--no-sandbox", "--disable-setuid-sandbox"]
  });
  const page = await browser.newPage();
  await page.setContent(html, { waitUntil: "networkidle0" });

  const image = await page.screenshot({ type: "png" });
  await browser.close();

  res.set({
    "Content-Type": "image/png",
    "Content-Disposition": `attachment; filename="bkash-screenshot.png"`
  });
  res.send(image);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
